<?php

$con = mysqli_connect("localhost","root","","regattendance");

if(!$con){
    die('Connection Failed'. mysqli_connect_error());
}

?>