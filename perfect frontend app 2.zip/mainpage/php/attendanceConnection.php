<?php
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "student_db";

// Create a connection to the database
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Function to insert data
function insertData($id, $name, $surname,$class,$student_number, $timestamp, $status) {
    global $conn;
    $sql = "INSERT INTO attendance(id, name, surname,class, student_number, timestamp, status)
            VALUES ('$id', '$name', '$surname', '$student_number',$class, '$timestamp', '$status')";

    if ($conn->query($sql) === TRUE) {
        return "Record inserted successfully";
    } else {
        return "Error: " . $sql . "<br>" . $conn->error;
    }
}

// Function to fetch data
function fetchData() {
    global $conn;
    $sql = "SELECT * FROM attendance";
    $result = $conn->query($sql);
    $data = array();

    if ($result->num_rows > 0) {
        while ($row = $result->fetch_assoc()) {
            $data[] = $row;
        }
    }
    return $data;
}

$conn->close();
?>
