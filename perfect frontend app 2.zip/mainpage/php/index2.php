<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Myclass</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-1BmE4kWBq78iYhFldvKuhfTAU6auU8tT94WrHftjDbrCEXSU1oBoqyl2QvZ6jIW3" crossorigin="anonymous">

</head>
<body style="margin:50px;">
    <h1>Attendance</h1>
    <br>
    <table class="table">
        <thead>
            <tr>
                <th>ID</th>
                <th>FIRST NAME</th>
                <th>LAST NAME</th>
                <th>STUDENT_NO</th>
                <th>TIME IN</th>
            </tr>
        </thead>
        <tbody>
            <?php
$servername="localhost";
$username="root";
$password="";
$database="student_db";

//create connection
$connection= new mysqli($servername,$username,$password,$database);

//check connection
if($connection->connect_error){
    die("connection failed: ". $connection->connect_error);

}
//read all the row from the table
$sql ="SELECT* FROM attendants_02";
$result = $connection->query($sql);

if(!$result){
die("invalid query:". $connection->error);
}

while($row = $result->fetch_assoc()){
    
    echo "<tr>
    <td>" . $row["id"] .   "</td>
    <td> ". $row["first_name"] ."  </td>
    <td> " . $row["last_name"] ." </td>
    <td>" . $row["student_no"]  ." </td>
    <td>"  . $row["time_in"] . "</td>
    </tr>";
}

?>

            
        </tbody>
    </table>
</body>
</html> 