<?php
require_once 'PHPExcel.php';

// MySQL database configuration
$db_host = 'localhost';
$db_user = 'username';
$db_pass = 'root';
$db_name = 'student_db';

// Create a connection to the database
$conn = new mysqli($db_host, $db_user, $db_pass, $db_name);

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Retrieve attendance data from the database
$sql = "SELECT id,name,surname,student_number,class,timestamp, status FROM attendance";
$result = $conn->query($sql);

// Create a new PHPExcel object
$objPHPExcel = new PHPExcel();
$objPHPExcel->setActiveSheetIndex(0);
$sheet = $objPHPExcel->getActiveSheet();

// Add headers to the Excel file
$sheet->setCellValue('A1', 'id');
$sheet->setCellValue('B1', 'name');
$sheet->setCellValue('C1', 'surname');
$sheet->setCellValue('D1', 'student_number');
$sheet->setCellValue('E1', 'class');
$sheet->setCellValue('F1', 'timestamp');
$sheet->setCellValue('H1', 'status');

// Loop through the database results and add data to the Excel file
$row = 2;
while ($row_data = $result->fetch_assoc()) {
    $sheet->setCellValue('A' . $row, $row_data['id']);
    $sheet->setCellValue('B' . $row, $row_data['name']);
    $sheet->setCellValue('C' . $row, $row_data['surname']);
    $sheet->setCellValue('D' . $row, $row_data['student_number']);
    $sheet->setCellValue('E' . $row, $row_data['class']);
    $sheet->setCellValue('F' . $row, $row_data['timestamp']);
    $sheet->setCellValue('H' . $row, $row_data['status']);
    $row++;
}

// Save the Excel file
$writer = PHPExcel_IOFactory::createWriter($objPHPExcel, 'Excel2007');
$writer->save('attendance.xlsx');

// Close the database connection
$conn->close();
?>
