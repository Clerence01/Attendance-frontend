<?php
if ($_SERVER["REQUEST_METHOD"] == "POST") {
   
    $selectedDatabase = $_POST["classlistDatabase.php"];

  echo" href="classlistDatabase.php" ";

    
} else {
    echo "Invalid request.";
}
?>
